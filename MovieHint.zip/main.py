import Constants as keys
import telegram
from telegram.ext import *
import Responses as R

print("Bot Started")

def start_command (update,context):
    update.message.reply_text ("----------- WELCOME TO MOVIES HINT ------------\n\n...... TYPE 'MOVIES' TO GET HINTS ......")
    
def help_command (update,context):
    update.message.reply_text ("Sorry for the  inconvenience, But we are in alpha stage.")

def hello_command (update,context):
    update.message.reply_text ("Welcome to our bot\n\nHope you enjoy the suggestions ")
    
def handle_message (update,context):
    text = str(update.message.text).lower()
    Responses = R.sample_responses(text)
    update.message.reply_text (Responses)
    
def error(update,context):
    print(f"Update {update} caused error {context.error}")
    
def main():
    updater = Updater(keys.API_KEY, use_context=True)
    dp = updater.dispatcher
    
    dp.add_handler(CommandHandler('start', start_command))
    dp.add_handler(CommandHandler('help', help_command))
    dp.add_handler(CommandHandler('hello', hello_command))
    
    dp.add_handler(MessageHandler(Filters.text, handle_message))
    
    dp.add_error_handler(error)
    
    updater.start_polling()
    updater.idle()
    
    
main()