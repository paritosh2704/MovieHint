from datetime import datetime

def sample_responses(input_text):
    user_message = str(input_text).lower()
    
    if user_message in ('hello' ,'Hello' , 'hi' ,'Hi' , 'hii'):
        return "Hey, How's its Going....."
    
    if user_message in ('who are you' , 'who are you?' ):
        return "I am a Bot which helps you suggest movies"
    
    if user_message in ('time' , 'time?' ):
        now = datetime.now()
        date_time = now.strftime("%d/%m/%y , %H:%M:%S")
        return str(date_time)

    if user_message in ('movie' , 'movies' ):
        movie1 = ['--------- Type of Genre --------' , 'ACTION', 'SCI-FI', 'FANTASY', 'HORROR', 'COMEDY', 'THRILLER']
        return ('\n'.join(movie1))

    if user_message in ('action'):
        action1 = ['8. No Time to Die (2021)     IMDB-7.3/10',
'7. Bajocero (2021)     IMDB-6.2/10',
'6. Raging Fire (2021)     IMDB-6.6/10',
'5. The Suicide Squad (2016)     IMDB-7.2/10',
'4. Shang-Chi and the Legend of the Ten Rings (2021)     IMDB-7.4/10',
'3. Spider-Man: No Way Home (2021)     IMDB-8.3/10',
'2. Riders of Justice (2020)     IMDB-7.5/10',
'1. The Paper Tigers (2020)     IMDB-6.3/10',
'\n\nFor More Movies Click on Link',
'https://www.imdb.com/search/title/?title_type=feature&genres=action&explore=genres']
        return ('\n'.join(action1))

    if user_message in ('scifi', 'sci-fi'):
        scifi1 = ['8. Black Widow (2021)     IMDB-6.7/10',
'7. Free Guy (2021)     IMDB-7.1/10',
'6. Oxygen (2021)     IMDB-6.5/10',
'5. Little Fish (2020)     IMDB-6.8/10',
'4. The Suicide Squad (2021)     IMDB-7.2/10',
'3. A Quiet Place Part II (2021)     IMDB-7.2/10',
'2. The Mitchells vs. the Machines (2021)     IMDB-7.6/10',
'1. Evangelion: 3.0+1.01 Thrice Upon a Time (2021)      IMDB-8/10'
'\n\nFor More Movies Click on Link',
'https://www.imdb.com/search/title/?genres=sci-fi&title_type=feature&explore=genres']
        return ('\n'.join(scifi1))

    if user_message in ('fantasy'):
        fantasy1 = ['8. Doctor Strange  (2016)   IMDB-7.5/10'
'7. Willow  (1988)   IMDB-7.2/10',
'6. Excalibur (1981)    IMDB-7.3/10',
'5. The Dark Crystal (2019)    IMDB-8.4/10',
'4. Pan Labyrinth  (2006)   IMDB-',
'3. Harry Potter Film Series   (2001-2011)  IMDB-7-8/10',
'2. Lord Of The Ring  (2001-2003)   IMDB-8.8/10',
'1. Conclusion  (2015)   IMDB-8.2/10'
'\n\nFor More Movies Click on Link',
'https://www.imdb.com/search/title/?genres=fantasy&title_type=feature&explore=genres']
        return ('\n'.join(fantasy1))


    if user_message in ('horror'):
        horror1 = ['8. Dabbe 6: The Return (2015)     IMDB-5.6/10',
'7. The Conjuring 2 (2016)     IMDB-7.3/10',
'6. The Conjuring (2013)     IMDB-7.5/10',
'5. It (I) (2017)     IMDB-7.3/10',
'4. Shutter (II) (2004)     IMDB-7/10',
'3. Sinister (I) (2012)     IMDB-6.8/10',
'2. The Exorcist (1973)     IMDB-8.1/10',
'1. Insidious: Chapter 3 (2015)     IMDB-6.1/10'
'\n\nFor More Movies Click on Link',
'https://www.imdb.com/search/title/?genres=horror&title_type=feature&explore=genres']
        return ('\n'.join(horror1))

    if user_message in ('thriller'):
       thriller1 = ['8. Bullet Train (2022)     IMDB-....',
'7. No Time to Die (2021)     IMDB-7.3/10',
'6. Jurassic Park (1993)     IMDB-8.2/10',
'5. The Unbearable Weight of Massive Talent (2022)     IMDB-7.1/10',
'4. The Northman (2022)    IMDB-7.2/10',
'3. Interceptor (2022)     IMDB-5.5/10',
'2. Spiderhead (2022)     IMDB-5.4/10',
'1. Jurassic World Dominion (2022)     IMDB-6/10'
'\n\nFor More Movies Click on Link',
'https://www.imdb.com/search/title/?title_type=feature&genres=thriller']
       return ('\n'.join(thriller1))

    if user_message in ('comedy'):
      comedy1 = ['8. The Worst Person in the World (2021) IMDB-7.9/10',
'7. The Gentlemen (2019)     IMDB-7.8/10',
'6. Sing 2 (2021)     IMDB-7.4/10',
'5. CODA (2021)     IMDB-8/10',
'4. The Grand Budapest Hotel (2014)     IMDB-8.1/10 ',
'3. A Perfect Pairing (2022)     IMDB-6.1/10',
'2. Hustlers (2019)     IMDB-6.3/10',
'1. The Hangover (2009)     IMDB-7.7/10'
'\n\nFor More Movies Click on Link',
'https://www.imdb.com/search/title/?title_type=feature&genres=comedy']
      return ('\n'.join(comedy1))
        
    
    return "I dont understand what you say!!"